#include<iostream>
#include<stdio.h>
//#define max 100
#include "stack.h"
using namespace std;
int main()
{
	char name[20];
	stack s;
	int i,check=0;
	printf("\n enter the string name :");
	scanf("%s",name);
	printf("\n the entered name is :");
	puts(name);
	printf("\n \n \t < putting the array into stack >");
	for(i = 0; name[i] != '\0';i++)
	{
		s.push(name[i]);
	}
	printf("\n \t < stack push complete >");
	for(i=0;name[i] != '\0';i++)
	{
		printf("\n %c (array) = %c (stack peek) ???? ",name[i],s.peek());
		if(name[i] != s.pop())
		{
			check = 1;
			break;
		}
	}
	if(check ==0)
	{
		printf("\n yup its a palindrome");
	}
	else
	{
		printf("\n not a palindrome");
	}

	/*
	do{
	cout<<"\n\n enter\n 1 - push\n 2-pop\n 3-top\n 4 - end, enter ur choice :  ";
	cin>>no;

	switch(no)
	{
		case 1:
			cout<<"\n enter element to push : ";
			cin >> n;
			s.push(n);
		break;
		case 2:
			cout<<"\n popping out ";
			cout<<s.pop();
			break;
		case 3 : 
			cout<<"\n top function ";
			cout<<s.peek();
			break;
	}
	}
	while(no != 4);
*/		
	return 0;

};
/*
int main()
{
        stack s;
        int n;
        do{
        int n;
        do{
        stack s;
        int n;
        do{
        cout<<"\n\n enter\n 1 - push\n 2-pop\n 3-top\n 4 - end, enter ur choice :  ";
        cin>>n;

        switch(n)
        {
                case 1:
                        cout<<"\n enter element to push : ";
                        cin >> n;
                        s.push(n);
                break;
                case 2:
                        cout<<"\n popping out ";
                        cout<<s.pop();
                        break;
                case 3 :
                        cout<<"\n top function ";
                        cout<<s.peek();
                        break;
        }
        }
        while(n != 4);
        return 0;
}
;
}*/
